<?php
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
		<a target="_blank" href="show_scholarship_list.php">See all available scholarships</a><br>
		<a target="_blank" href="show_college_list.php">See all colleges</a><br>
	</body>
</html>