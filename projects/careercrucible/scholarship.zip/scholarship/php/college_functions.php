<?php
	if(session_status() === PHP_SESSION_NONE) {
		session_start();
	}

	function load_college($college_id) {
		if(!is_numeric($college_id)) {
			$college_id = (int)$college_id;
			if(!is_numeric($college_id)) {
				die("Error in load_college(): College ID is not a number\n");
			}
		}

		require("../db_connect.php");
		$college_id = mysqli_real_escape_string($db,$college_id);
		
		$college_result = mysqli_query($db,"SELECT * FROM college_info WHERE clg_id={$college_id} ;");
		if(!$college_result) {
			echo "SQL Error in load_college(): ".mysqli_error($db)."\n";
			mysqli_close($db);
			die();
		}
		else if(mysqli_num_rows($college_result) === 0) {
			echo "Input Error in load_college(): Invalid College ID\n";
			mysqli_close($db);
			die();
		}

		$college = mysqli_fetch_array($college_result,MYSQLI_ASSOC);
		mysqli_close($db);
		return $college;
	}

	function load_college_list() {
		require("../db_connect.php");
		$college_list_result = mysqli_query($db,"SELECT DISTINCT clg_name, clg_id FROM college_info ;");
		if(!$college_list_result) {
			echo "SQL Error in load_college_list() : ".mysqli_error($db)."\n";
			mysqli_close($db);
			die();
		}

		$college_list = array();
		while($tmp_college = mysqli_fetch_array($college_list_result,MYSQLI_ASSOC)) {
			array_push($college_list,$tmp_college);
		}
		mysqli_close($db);
		unset($tmp_college);

		return $college_list;
	}