
		<!-- navbar-->
		<header class="header">
			<div class="sticky-wrapper">
				<div role="navigation" class="navbar navbar-default">
					<div class="container">
						<div class="navbar-header">
							<button type="button" data-toggle="collapse" data-target=".navbar-collapse" class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a href="#intro" class="navbar-brand scroll-to" id="top"><p>CareerCrucible</p></a>
						</div>
						<div id="navigation" class="collapse navbar-collapse">
							<ul class="nav navbar-nav navbar-right">
								<li><a href="../../index.html">Home</a></li>
								<li class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#"id="test">Resources<span class="caret"></span></a>
									<ul class="dropdown-menu">
										<li><a href="../../eng colleges/engcol.html"id="test1" >Engineering colleges</a></li>
										<li><a href="../../engexams/engExams.html"id="test1" >Engineering exams</a></li>
										<li><a href="../../calender/examcalender.html" id="test1">Exam calender</a></li>
										<li><a href="../../branch info/branchmain.html"id="test1" >Branch Info</a></li>
										<li><a href="../../branchreview/br.html" id="test1">Branch Review</a></li>
									</ul>
								</li>
								<li><a href="../../news/news.php">News</a></li>
								<li><a href="../../Forum/forum.php">Forum</a></li>
								<li><a href="../../counselling/counselling.php">Counselling</a></li>
								<li><a href="#">Login</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- /.navbar-->