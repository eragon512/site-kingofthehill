
		<div class="footer-section bottom">
			<div class="container">
				<div class="footer-grids">
					<ul class="footerlinks">
						<li><a href="../../aboutus.html">About Us</a></li>
						<li><a href="../../team/team.html">Our Team</a></li>
						<li><a href="../../privacy.html">Privacy Policy</a></li>
						<li><a href="../../contactus.html">Contact Us</a></li>
						<li><a href="../../FAQ/faq.html">FAQs</a></li>
						<li><a href="../../feedback.php">Feedback</a></li>
					</ul>
					<div class="copyright">&copy; Career Crucible. All Rights Reserved.</div>
				</div>
			</div>
		</div>