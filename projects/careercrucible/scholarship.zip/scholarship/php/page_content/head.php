
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="robots" content="all,follow">
		<!-- Bootstrap and Font Awesome css-->
		
		<!-- we use cdn but you can also include local files located in css directory-->
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/themify-icons.css">
		<link rel="stylesheet" href="../css/bootstrap.min.css">

		<!-- Google fonts - Roboto Condensed for headings, Open Sans for copy-->
		<link rel="stylesheet" href="css/font-min.css">
		<!-- theme stylesheet-->
		<link rel="stylesheet" href="css/style.css" id="theme-stylesheet">
		<!-- Favicon-->
		<link rel="shortcut icon" href="favicon.png">