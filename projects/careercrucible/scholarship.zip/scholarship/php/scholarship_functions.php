<?php
	if(session_status() === PHP_SESSION_NONE) {
		session_start();
	}

	function load_scholarship_list() {
		require("../db_connect.php");
		$scholarship_list_result = mysqli_query($db,"SELECT * FROM scholarship_list ;");
		if(!$scholarship_list_result) {
			echo "SQL Error in load_scholarship_list() : ".mysqli_error($db)."\n";
			mysqli_close($db);
			die();
		}

		$scholarship_list = array();
		while($tmp_scholarship = mysqli_fetch_array($scholarship_list_result,MYSQLI_ASSOC)) {
			array_push($scholarship_list,$tmp_scholarship);
		}
		mysqli_close($db);
		unset($tmp_scholarship);

		return $scholarship_list;
	}

	function load_college_scholarship_list($college_id) {
		if(!is_numeric($college_id)) {
			$college_id = (int)$college_id;
			if(!is_numeric($college_id)) {
				die("Error in load_college_scholarship_list(): College ID is not a number\n");
			}
		}

		require("../db_connect.php");
		$college_id = mysqli_real_escape_string($db,$college_id);
		$college_scholarship_list_result = mysqli_query($db,"SELECT * FROM college_info NATURAL JOIN scholarship_college_list NATURAL JOIN scholarship_list WHERE clg_id={$college_id} ;");
		if(!$college_scholarship_list_result) {
			echo "SQL Error in load_college_scholarship_list(): ".mysqli_error($db)."\n";
			mysqli_close($db);
			die();
		}

		$college_scholarship_list = array();
		while($tmp_scholarship = mysqli_fetch_array($college_scholarship_list_result,MYSQLI_ASSOC)) {
			array_push($college_scholarship_list,$tmp_scholarship);
		}
		mysqli_close($db);
		unset($tmp_scholarship);

		return $college_scholarship_list;
	}

	function load_scholarship($scholarship_id) {
		if(!is_numeric($scholarship_id)) {
			$scholarship_id = (int)$scholarship_id;
			if(!is_numeric($scholarship_id)) {
				die("Error in load_scholarship(): College ID is not a number\n");
			}
		}

		require("../db_connect.php");
		$scholarship_id = mysqli_real_escape_string($db,$scholarship_id);
		$scholarship_result = mysqli_query($db,"SELECT * FROM scholarship_list WHERE scholarship_id={$scholarship_id} ;");
		if(!$scholarship_result) {
			echo "SQL Error in load_scholarship(): ".mysqli_error($db)."\n";
			mysqli_close($db);
			die();
		}

		$scholarship = mysqli_fetch_array($scholarship_result,MYSQLI_ASSOC);
		mysqli_close($db);

		return $scholarship;
	}

	function submit_scholarship_application() {
		require_once("users_functions.php");
		if(!($current_user = load_current_user())) {
			header("Location: ./");
		}

		$current_user["id"];
	}