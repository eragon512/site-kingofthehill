<?php
	if(session_status() === PHP_SESSION_NONE) {
		session_start();
	}

	function load_current_user() {
		if(isset($_SESSION["username"]) && $_SESSION["username"]) {
			$user_email = $_SESSION["username"];
			require("../db_connect.php");
			$user_email = mysqli_real_escape_string($db,$user_email);

			$user_result = mysqli_query($db,"SELECT * FROM student WHERE email={$user_email} ;");
			if(!$user_result) {
				echo "SQL Error in load_current_user(): ".mysqli_error($db)."\n";
				mysqli_close($db);
				die();
			} else if(mysqli_num_rows($user_result) === 0) {
				echo "Input Error in load_current_user(): Invalid name for User\n";
				mysqli_close($db);
				die();
			} else if(mysqli_num_rows($user_result) > 1) {
				echo "Error in load_current_user(): Multiple users for same name\n";
				mysqli_close($db);
				die();
			}

			$current_user = mysqli_fetch_array($user_result,MYSQLI_ASSOC);
			mysqli_close($db);

			return $current_user;
		} else {
			echo "Error: User not logged in";
			return NULL;
		}
	}