<?php
	session_start();
	if(isset($_SESSION["username"])) {
		echo $_SESSION["username"]."<br>";
	}
	require_once("php/scholarship_functions.php");
	$scholarship_list = load_scholarship_list();
?>

<!DOCTYPE html>
<html>
	<head>
		<?php require_once("php/page_content/head.php") ?>
		<title>All Scholarships | CareerCrucible</title>
	</head>
	<body>
		Scholarships List: <br>
		<?php
			foreach($scholarship_list as $scholarship) {
				echo "<a href='show_scholarship.php?scholarship_id={$scholarship["scholarship_id"]}'>".$scholarship["scholarship_name"]."</a><br>";
			}
		?>
	</body>
</html>