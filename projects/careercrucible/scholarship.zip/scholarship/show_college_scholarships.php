<?php
	session_start();
	if(isset($_SESSION["username"])) {
		echo $_SESSION["username"]."<br>";
	}

	require_once("php/college_functions.php");
	if(isset($_GET["college_id"])) {
		$college_id = $_GET["college_id"];
		$college = load_college($college_id);
		if($college) {
			require_once("php/scholarship_functions.php");
			$scholarship_list = load_college_scholarship_list($college_id);
		} else {
			die("Invalid College ID");
		}
	} else {
		die("Invalid College ID");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<?php require_once("php/page_content/head.php") ?>
		<title>Scholarships | CareerCrucible</title>
	</head>
	
	<body>
		List of Scholarships offered by <?php echo "{$college["clg_name"]}" ?> :
		<br><br>
		<?php
			foreach($scholarship_list as $scholarship) {
				echo "<a target='_blank' href='show_scholarship.php?scholarship_id={$scholarship["scholarship_id"]}'>".$scholarship["scholarship_name"]."</a><br>";
			}
		?>
	</body>
</html>