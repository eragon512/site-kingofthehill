<?php
	session_start();
	if(isset($_SESSION["username"])) {
		echo $_SESSION["username"]."<br>";
	}

	require_once("php/scholarship_functions.php");
	if(isset($_GET["scholarship_id"])) {
		$scholarship_id = $_GET["scholarship_id"];
		$scholarship = load_scholarship($scholarship_id);
		if(!$scholarship) {
			die("Invalid Scholarship ID");
		}
	} else {
		die("Invalid Scholarship ID");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<?php require_once("php/page_content/head.php") ?>
		<title> <?php echo $scholarship["scholarship_name"]; ?> | CareerCrucible</title>
	</head>
	
	<body>
		<div class="container-fluid">
			<h2><?php echo $scholarship["scholarship_name"]; ?></h2>
			<div>
				<?php echo $scholarship["scholarship_description"]; ?>
			</div>
			<div class="row">
				<div class="col-xs-4">
					<div>Apply Now</div>
					<div><a href='apply_scholarship.php?scholarship_id={$scholarship["scholarship_id"]}'>Apply Here</a></div>
				</div>
				<div class="col-xs-4">
					<div>Scholarship Amount</div>
					<div> <?php echo $scholarship["scholarship_amount"]; ?> </div>
				</div>
				<div class="col-xs-4">
					<div>Scholarship Deadline</div>
					<div> <?php echo $scholarship["scholarship_deadline"]; ?> </div>
				</div>
			</div>
		</div>
	</body>
</html>