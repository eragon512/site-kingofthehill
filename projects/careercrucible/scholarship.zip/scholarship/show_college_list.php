<?php
	session_start();
	if(isset($_SESSION["username"])) {
		echo $_SESSION["username"]."<br>";
	}
	require_once("php/college_functions.php");
	$college_list = load_college_list();
?>

<!DOCTYPE html>
<html>
	<head>
		<?php require_once("php/page_content/head.php") ?>
		<title>All Colleges | CareerCrucible</title>
	</head>
	<body>
		Colleges List:
		<br><br>
		<?php
			foreach($college_list as $college) {
				echo "<a target='_blank' href='show_college_scholarships.php?college_id={$college["clg_id"]}'>".$college["clg_name"]."</a><br>";
			}
		?>
	</body>
</html>