<?php
	session_start();
	if(isset($_SESSION["username"]) || $_SESSION["username"]) {
		echo $_SESSION["username"]."<br>";
	} else {
		header("Location: ../slots/junior/");
	}
	require_once("php/student_functions.php");
	$user = load_current_student();

	require_once("php/scholarship_functions.php");
	if(isset($_GET["scholarship_id"])) {
		$scholarship_id = $_GET["scholarship_id"];
		$scholarship = load_scholarship($scholarship_id);
		if(!$scholarship) {
			die("Invalid Scholarship ID");
		}
	} else {
		die("Invalid Scholarship ID");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<?php require_once("php/page_content/head.php") ?>
		<title> <?php echo $scholarship["scholarship_name"] ?> | CareerCrucible</title>
	</head>
	<body>
		<?php require("php/page_content/fb-login.php"); ?>
		<?php require("php/page_content/navbar.php"); ?>
		
		<div>
			<h2>Apply for <?php echo $scholarship["scholarship_name"] ?></h2>
			<form role="form" action="">
			</form>
		</div>

		<?php require("php/page_content/footer.php"); ?>
	</body>
</html>